<?php
session_start();
$conne =mysqli_connect("localhost","root","Abhi@8820","login_data");
if($conne){
    // echo "kdjsfhjgjgjg";
}

?>